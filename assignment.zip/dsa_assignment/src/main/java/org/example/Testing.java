package org.example;

import java.util.ArrayList;
public class Testing {
    public static void main(String[] args){
        ArrayList<Integer> collection = new ArrayList<>();
        collection.add(23);
        System.out.print(collection.getFirst());
    }
}
